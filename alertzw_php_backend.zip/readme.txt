adding reports
confirming reports
scanning fences
generating alerts & notifications
reports
illustrating on map
ecocash contributions
financial statements
