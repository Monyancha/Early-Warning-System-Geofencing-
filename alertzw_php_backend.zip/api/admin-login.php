<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {
        $request = json_decode($postdata);
        $email = mysqli_real_escape_string($conn,$request->email);
        $password =mysqli_real_escape_string($conn,$request->password);

        $statement="SELECT * FROM tblusers JOIN tbladministrators ON tblusers.flduser_id=tbladministrators.flduser_id WHERE tbladministrators.fldemail='$email' and fldpassword=MD5('$password') LIMIT 0,1";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        if(mysqli_num_rows($query)==1){
            $response=mysqli_fetch_assoc($query);
            if($response['fldstatus']=='Active'){
                $response['response']='success';
            }else{
                $response['error']='account disabled';
            }
        }else{
            $response=array("response"=>"failed");
        }
    } else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
}
?>