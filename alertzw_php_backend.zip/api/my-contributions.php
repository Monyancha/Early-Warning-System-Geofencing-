<?php
include("connection.php");
$contributions=array();
if(isset($_GET["user_id"])){
	$user_id=mysqli_real_escape_string($conn,$_GET["user_id"]);
	$statement="SELECT tblcontributions.fldcontribution_id,tblcontributions.fldreport_id,tblcontributions.flddescription,tblcontributions.flddebit,tblreports.fldtitle,tblreports.fldpicture,tblcontributions.fldtimestamp FROM tblcontributions JOIN tblreports ON tblcontributions.fldreport_id=tblreports.fldreport_id WHERE tblcontributions.flduser_id='$user_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$contributions[]=$record;
	}
}
echo json_encode($contributions);   
?>