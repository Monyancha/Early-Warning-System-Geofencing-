<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $record=json_decode($postdata);
            $user_id=mysqli_real_escape_string($conn,$record->user_id);
            $report_id=mysqli_real_escape_string($conn,$record->report_id);
            $phoneno=mysqli_real_escape_string($conn,$record->phoneno);
            $amount=mysqli_real_escape_string($conn,$record->amount);
            $timestamp=date('Y-m-d H:i:s');
            $amount_cents=$amount*100;
            $statement="INSERT INTO tblcontributions (flduser_id,fldreport_id,flddescription,flddebit,fldcredit,fldtimestamp) VALUES('$user_id','$report_id','Ecocash Transfare ($phoneno)','$amount_cents','0','$timestamp')";                  
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));

            $response=array("response"=>"success");
        }else{
            $response=array("response"=>"failed");
        }
    }else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
?>