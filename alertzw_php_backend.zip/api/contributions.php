<?php
include("connection.php");
$data=array();
if(isset($_GET["report_id"])){
	$contributions=array();
	$report_id=mysqli_real_escape_string($conn,$_GET["report_id"]);
	$statement="SELECT tblcontributions.fldcontribution_id,tblcontributions.flddescription,tblcontributions.flddebit,tblusers.fldforename,tblusers.fldsurname,tblusers.flduser_id,tblcontributions.fldtimestamp FROM tblcontributions JOIN tblusers ON tblcontributions.flduser_id=tblusers.flduser_id WHERE tblcontributions.fldreport_id='$report_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$contributions[]=$record;
	}

	$statement="SELECT SUM(tblcontributions.flddebit) FROM tblcontributions JOIN tblusers ON tblcontributions.flduser_id=tblusers.flduser_id WHERE tblcontributions.fldreport_id='$report_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$total=mysqli_fetch_assoc($query)["SUM(tblcontributions.flddebit)"];       

	$data["contributions"]=$contributions;
	$data["total"]=$total;
}
echo json_encode($data);   
?>