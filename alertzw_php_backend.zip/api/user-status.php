<?php
include("connection.php");
if(isset($_GET["user_id"]) && isset($_GET["activate"])){        
	$user_id = mysqli_real_escape_string($conn,$_GET["user_id"]);
	if($_GET["activate"]=="true"){
		$statement="UPDATE tblusers SET fldstatus='Active' WHERE flduser_id='$user_id'";
	}else{
		$statement="UPDATE tblusers SET fldstatus='Deactive' WHERE flduser_id='$user_id'";
	}
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>