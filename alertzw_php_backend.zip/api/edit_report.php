<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata) && isset($_GET["report_id"])) {
	        $request = json_decode($postdata);
	        $report_id=mysqli_real_escape_string($conn,$_GET["report_id"]);
	       	$title=mysqli_real_escape_string($conn,$request->title);
	        $type=mysqli_real_escape_string($conn,$request->type);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $measure=mysqli_real_escape_string($conn,$request->measure);
	        $latitude=mysqli_real_escape_string($conn,$request->latitude);
	        $longitude=mysqli_real_escape_string($conn,$request->longitude);
	        $radius=mysqli_real_escape_string($conn,$request->radius);
	        $picture=$request->picture;
	        $statement="UPDATE tblreports SET fldtitle='$title', fldtype='$type',flddescription='$description',fldmeasure='$measure',fldlatitude='$latitude',fldlongitude='$longitude',fldradius='$radius',fldpicture='$picture' WHERE fldreport_id='$report_id'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>