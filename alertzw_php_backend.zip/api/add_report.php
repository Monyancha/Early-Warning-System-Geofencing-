<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);

	        $title=mysqli_real_escape_string($conn,$request->title);
	        $type=mysqli_real_escape_string($conn,$request->type);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $measure=mysqli_real_escape_string($conn,$request->measure);
	        $latitude=mysqli_real_escape_string($conn,$request->latitude);
	        $longitude=mysqli_real_escape_string($conn,$request->longitude);
	        $radius=mysqli_real_escape_string($conn,$request->radius);
	        $date=date('Y-m-d H:i:s');
	        $picture=$request->picture;

	        $statement="INSERT INTO tblreports(fldtitle,fldtype,flddescription,fldmeasure,fldlatitude,fldlongitude,fldradius,fldtimestamp,fldpicture,fldstatus) VALUES('$title Zone','$type','$description','$measure','$latitude','$longitude','$radius','$date','$picture','Pending')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>