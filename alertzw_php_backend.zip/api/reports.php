<?php
include("connection.php");
$reports=array();
if(isset($_GET["active"])){
	$statement="SELECT * FROM tblreports WHERE fldstatus='Active'";
}else{
	$statement="SELECT * FROM tblreports WHERE fldstatus='Pending'";
}
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $reports[]=$record;
}
echo json_encode($reports);   
?>